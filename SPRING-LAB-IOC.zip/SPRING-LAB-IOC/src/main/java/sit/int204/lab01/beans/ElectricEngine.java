package sit.int204.lab01.beans;

public class ElectricEngine implements Engine {
    @Override
    public void turnOn() {
        System.out.println("Turn On - Electric Engine");
    }

    @Override
    public int getCapacity() {
        return 0;
    }

    @Override
    public void turnOff() {
        System.out.println("Turn Off - Electric Engine");
    }

}
