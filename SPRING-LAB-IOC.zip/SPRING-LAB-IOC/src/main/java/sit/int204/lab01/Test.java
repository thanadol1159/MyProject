package sit.int204.lab01;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import sit.int204.lab01.beans.Car;
import sit.int204.lab01.beans.Engine;
import sit.int204.lab01.beans.GasolineEngine;

public class Test {
    public static void main(String[] args) {
        test();
        testLooseXml();
    }

    private static void test(){
        Engine ge=new GasolineEngine(3000);
        Car carA=new Car("ZB25478-23958D","honda",ge);
        carA.start();
        System.out.println(carA);
    }
    private static void testLooseXml() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationConfig.xml");
        Car car = (Car) context.getBean("car");
        car.start();
        System.out.println(car);
    }

}





