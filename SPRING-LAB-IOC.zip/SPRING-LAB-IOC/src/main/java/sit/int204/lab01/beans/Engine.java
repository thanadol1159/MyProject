package sit.int204.lab01.beans;

    public interface Engine {
        public void turnOn();

        public int getCapacity();

        public void turnOff();

}
