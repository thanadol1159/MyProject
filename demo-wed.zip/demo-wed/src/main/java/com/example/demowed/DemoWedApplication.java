package com.example.demowed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWedApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoWedApplication.class, args);
	}

}
