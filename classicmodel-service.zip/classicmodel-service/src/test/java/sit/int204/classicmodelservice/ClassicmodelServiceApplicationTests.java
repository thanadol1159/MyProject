package sit.int204.classicmodelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassicmodelServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
