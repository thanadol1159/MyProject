package sit.int204.classicmodelservice.entitie;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SimpleCustomerDto {
    private String customerName;
    private String phone;
    private String city;
    private String country;
    private String salesPerson;
}