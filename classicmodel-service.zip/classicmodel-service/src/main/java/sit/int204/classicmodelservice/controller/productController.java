//package sit.int204.classicmodelservice.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.web.bind.annotation.*;
//import sit.int204.classicmodelservice.entitie.Product;
//import sit.int204.classicmodelservice.service.ProductService;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/products")
//public class productController {
//    @Autowired
//    private ProductService productService;
//
//    @GetMapping("/pages")
//    public Page<Product> getProductPage(
//            @RequestParam(defaultValue = "0") Integer page,
//            @RequestParam(defaultValue = "10") Integer size,
//            @RequestParam(defaultValue = "productCode") String sortBy
//    ) {
//        return productService.getProductByPage(page, size, sortBy);
//    }
//
//    @GetMapping("/Contexts")
//    public List<Product> getProductByContext(@RequestParam String name, @RequestParam String Description){
//        return productService.getProductsByContext(name,Description);
//    }
//    @GetMapping("/prices/{low}/{high}")
//    public List<Product> getProductByPrices(@PathVariable double low, @PathVariable double high){
//        return productService.getProductsPriceBetween(low,high);
//    }
//
//    @GetMapping("/prices/{low}/{high}")
//    public List<Product> getProductFil(
//            @PathVariable double low,
//            @PathVariable double high){
//        return productService.getProductsPriceBetween(low,high);
//    }
//
//    @GetMapping("/{productLine}")
//    public List<Product> getProductByProductLine(
//            @PathVariable String productLine,
//            @RequestParam(defaultValue = "productCode") String sortBy){
//        return productService.getProductByProductLine(productLine,sortBy);
//    }
//
//    @PutMapping("/{producCode}")
//    public Product updateProduct(@RequestBody Product product, @PathVariable String producCode){
//        return productService.updateProduct(producCode,product);
//    }
//
//
//    @PostMapping("")
//    public Product createNewProduct(@RequestBody Product product) {
//        return productService.createNewProduct(product);
//    }
//
//
//
//}
