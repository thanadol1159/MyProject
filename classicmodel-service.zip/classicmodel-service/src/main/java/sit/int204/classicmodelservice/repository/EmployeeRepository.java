package sit.int204.classicmodelservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodelservice.entitie.Employee;

public interface  EmployeeRepository extends JpaRepository<Employee,Integer> {
}
