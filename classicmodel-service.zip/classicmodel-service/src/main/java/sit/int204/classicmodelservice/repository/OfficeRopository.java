package sit.int204.classicmodelservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodelservice.entitie.Office;

public interface OfficeRopository extends JpaRepository<Office,String> {
}
