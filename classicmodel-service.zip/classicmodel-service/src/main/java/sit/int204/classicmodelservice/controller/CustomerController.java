//package sit.int204.classicmodelservice.controller;
//
//import org.modelmapper.ModelMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//import sit.int204.classicmodelservice.entitie.SimpleCustomerDto;
//import sit.int204.classicmodelservice.service.CustomerService;
//
//@RestController
//public class CustomerController {
////    @Autowired
////    private CustomerService service;
////    @Autowired
////    private ModelMapper modelMapper;
////    @GetMapping("/{customerId}")
////    public SimpleCustomerDto getSimpleCustomerById(@PathVariable Integer customerId) {
////        return modelMapper.map(service.getCustomerById(customerId),SimpleCustomerDto.class);
////    }
//}