//package sit.int204.classicmodelservice.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.client.HttpClientErrorException;
//import sit.int204.classicmodelservice.entitie.Product;
//import sit.int204.classicmodelservice.repository.ProductRepository;
//
//import java.util.List;
//
//@Service
//public class ProductService {
//    @Autowired
//    private ProductRepository productRepository;
//
//    @GetMapping("/pages")
//    public Page<Product> getProductByPage(int page, int size, String sortBy) {
//        Sort sort = Sort.by(sortBy);
//        Pageable pageable = PageRequest.of(page, size, sort);
//
//        return productRepository.findAll(pageable);
//    }
//
//    public List<Product> getProductsByContext(String name, String Description){
//        return productRepository.findProductsByProductNameStartingWithOrProductDescriptionContaining(name, Description);
//    }
//
//    public List<Product> getProductsPriceBetween(Double low,Double high){
//        if (low > high){
//            return productRepository.findProductsByPriceBetweenOrderByPriceDesc(high,low);
//        }else {
//            return productRepository.findProductsByPriceBetweenOrderByPriceDesc(low, high);
//        }
//
//    }
//
//    public List<Product> getProductByProductLine(String productLine , String sortBy) {
//        Sort sort = Sort.by(sortBy);
//        return productRepository.findProductsByProductLine(productLine , sort);
//    }
//
//    public Product updateProduct(String productCode,Product product) {
//        Product existingProduct = productRepository.findById(productCode).orElseThrow(
//                () -> new HttpClientErrorException(HttpStatus.NOT_FOUND, "ProductCode" + productCode +" not found")
//        );
//
//        existingProduct.setProductLine(product.getProductLine());
//        existingProduct.setProductName(product.getProductName());
//        existingProduct.setProductDescription(product.getProductDescription());
//        existingProduct.setPrice(product.getPrice());
//        existingProduct.setQuantityInStock(product.getQuantityInStock());
//        existingProduct.setBuyPrice(product.getBuyPrice());
//        return productRepository.saveAndFlush(existingProduct);
//    }
//
//    public Product createNewProduct(Product product){
//        return productRepository.saveAndFlush(product);
//    }
//
//
//
//
//}
