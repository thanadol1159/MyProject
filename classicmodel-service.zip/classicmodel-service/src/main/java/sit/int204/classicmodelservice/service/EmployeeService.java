package sit.int204.classicmodelservice.service;

public class EmployeeService {
}
