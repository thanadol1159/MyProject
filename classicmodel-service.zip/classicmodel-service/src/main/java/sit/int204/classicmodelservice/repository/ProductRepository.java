//package sit.int204.classicmodelservice.repository;
//
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.data.jpa.repository.JpaRepository;
//import sit.int204.classicmodelservice.entitie.Product;
//
//import java.util.List;
//
//public interface ProductRepository extends JpaRepository <Product,String> {
//    List<Product> findProductsByProductNameStartingWithOrProductDescriptionContaining(String name, String description);
//    Page<Product> findProductsByProductNameStartingWithOrProductDescriptionContaining(String name, String description, Pageable page);
//    List<Product> findProductsByProductNameStartingWithOrProductDescriptionContaining(String name, String description, Sort sort);
//    List<Product> findProductsByPriceBetweenOrderByPriceDesc(Double low,Double high);
//
//    Page<Product> findProductsByPriceBetweenOrderByPriceDesc(Double low,Double high,Pageable pageable);
//
//    List<Product> findProductsByProductLine(String name, Sort sortBy);
//}